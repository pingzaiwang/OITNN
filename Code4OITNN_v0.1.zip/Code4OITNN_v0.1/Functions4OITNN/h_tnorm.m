function f=h_tnorm(X)
f=norm(double(X(:)));
end
