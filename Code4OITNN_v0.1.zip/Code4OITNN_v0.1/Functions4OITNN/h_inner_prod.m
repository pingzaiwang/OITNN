function val=h_inner_prod(X,Y)
val=X(:)'*Y(:);
