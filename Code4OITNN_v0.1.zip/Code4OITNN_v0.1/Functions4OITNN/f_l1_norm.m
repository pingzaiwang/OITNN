function xnorm = f_l1_norm(X)
xnorm=sum(abs(X(:)));
end