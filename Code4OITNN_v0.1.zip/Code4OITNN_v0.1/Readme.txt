
-------------------------------------------------------------------------------------
Sample code (version 0.1) for the following paper:

Andong WANG, Chao LI, Zhong JIN, Qibin ZHAO. 
"Robust Tensor Decomposition via Orientation Invariant Tubal Nuclear Norms," in AAAI 2020
-------------------------------------------------------------------------------------


For any questions, please contract Andong WANG (w.a.d@outlook.com)
