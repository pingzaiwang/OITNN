function f = h_inf_norm(A)
a=double(A(:));
f=max(abs(a));
end