function f=f_l_inf_norm(Y)
f=max(abs(Y(:))); 
end
